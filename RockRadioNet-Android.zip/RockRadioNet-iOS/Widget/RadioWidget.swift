import SwiftUI
import UIKit
import WidgetKit
import AppIntents

// MARK: - Данные

struct RadioEntry: TimelineEntry {
    let date: Date
    let state: Shared.State
    let image: UIImage?
}

struct RadioProvider: TimelineProvider {
    func placeholder(in context: Context) -> RadioEntry {
        var s = Shared.State()
        s.hasStations = true
        s.hasCurrent = true
        s.name = "RockRadioNet"
        s.artist = "Исполнитель"
        s.title = "Название песни"
        s.playing = true
        return RadioEntry(date: Date(), state: s, image: nil)
    }

    func getSnapshot(in context: Context, completion: @escaping (RadioEntry) -> Void) {
        completion(context.isPreview ? placeholder(in: context) : current())
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<RadioEntry>) -> Void) {
        completion(Timeline(entries: [current()], policy: .never))
    }

    private func current() -> RadioEntry {
        let s = Shared.load()
        var img: UIImage?
        if !s.coverStamp.isEmpty, let f = Shared.coverFile {
            img = UIImage(contentsOfFile: f.path)
        }
        return RadioEntry(date: Date(), state: s, image: img)
    }
}

// MARK: - Вид в стиле нижнего проигрывателя

private extension Color {
    init(hex: UInt32) {
        self.init(red: Double((hex >> 16) & 0xFF) / 255,
                  green: Double((hex >> 8) & 0xFF) / 255,
                  blue: Double(hex & 0xFF) / 255)
    }
}

struct RadioWidgetView: View {
    let entry: RadioEntry

    private var s: Shared.State { entry.state }
    private var hasTrack: Bool { !s.title.isEmpty }

    private var topLine: String {
        if !s.hasCurrent { return "RockRadioNet" }
        return hasTrack ? (s.artist.isEmpty ? s.name : s.artist) : s.name
    }

    private var secondLine: String {
        if !s.error.isEmpty { return s.error }
        if hasTrack { return s.title }
        if !s.hasStations { return "Откройте приложение" }
        if !s.hasCurrent { return "Выберите станцию" }
        return s.playing ? (s.genre.isEmpty ? "В эфире" : s.genre) : "Пауза"
    }

    private var status: String {
        if !s.hasCurrent { return "[—]" }
        return s.playing ? "[LIVE]" : "[ПАУЗА]"
    }

    var body: some View {
        HStack(spacing: 6) {
            cover
            VStack(spacing: 1) {
                Text(topLine)
                    .font(.system(size: 15, weight: .bold))
                    .foregroundColor(Color(hex: 0xF5D5A6))
                    .lineLimit(1)
                Text(secondLine)
                    .font(.system(size: 14))
                    .foregroundColor(Color(hex: 0xC6CADF))
                    .lineLimit(1)
                Text(status)
                    .font(.system(size: 10))
                    .foregroundColor(Color(hex: 0x7F8498))
                Rectangle()
                    .fill(LinearGradient(colors: [.clear, Color(hex: 0x0F1116), .clear],
                                         startPoint: .leading, endPoint: .trailing))
                    .frame(height: 2)
                    .padding(.vertical, 3)
                controls
            }
            .frame(maxWidth: .infinity)
        }
        .padding(.leading, 12)
        .padding(.trailing, 8)
        .containerBackground(for: .widget) {
            LinearGradient(colors: [Color(hex: 0x2B2F3A), Color(hex: 0x22252E)],
                           startPoint: .top, endPoint: .bottom)
        }
    }

    private var cover: some View {
        ZStack(alignment: .leading) {
            Circle()
                .fill(RadialGradient(colors: [Color(hex: 0x5A5D68), Color(hex: 0x2C2E36), Color(hex: 0x0B0C0F)],
                                     center: UnitPoint(x: 0.92, y: 0.5), startRadius: 2, endRadius: 52))
                .overlay(Circle().stroke(Color.black.opacity(0.7), lineWidth: 1))
                .frame(width: 78, height: 78)
                .offset(x: 16)
            ZStack {
                if let img = entry.image {
                    Image(uiImage: img).resizable().scaledToFill()
                } else if s.hasCurrent {
                    Color(Shared.stationColor(s.name))
                    Text(String(s.name.prefix(1)).uppercased())
                        .font(.system(size: 36, weight: .bold))
                        .foregroundColor(.white)
                } else {
                    Color(hex: 0x555555)
                    Image(systemName: "music.note").font(.system(size: 30)).foregroundColor(.white)
                }
            }
            .frame(width: 84, height: 84)
            .clipped()
            .shadow(color: .black.opacity(0.5), radius: 6, x: -4, y: 5)
        }
        .frame(width: 100, alignment: .leading)
    }

    private var controls: some View {
        HStack(spacing: 2) {
            Button(intent: ReconnectIntent()) {
                small("arrow.clockwise", color: Color(hex: 0xF2CF9A))
            }
            Button(intent: PrevStationIntent()) {
                knob("backward.fill", size: 36, cap: 24, top: 0x444957, bottom: 0x323641)
            }
            Button(intent: TogglePlayIntent()) {
                knob(s.playing ? "pause.fill" : "play.fill", size: 46, cap: 32, top: 0x5D6371, bottom: 0x3C414D)
            }
            Button(intent: NextStationIntent()) {
                knob("forward.fill", size: 36, cap: 24, top: 0x444957, bottom: 0x323641)
            }
            Button(intent: ShuffleStationIntent()) {
                small("shuffle", color: Color(hex: 0x9FA3B1))
            }
        }
        .buttonStyle(.plain)
    }

    private func small(_ icon: String, color: Color) -> some View {
        Image(systemName: icon)
            .font(.system(size: 11, weight: .bold))
            .foregroundColor(color)
            .frame(width: 24, height: 24)
            .background(Circle().fill(Color(hex: 0x2A2D37)))
    }

    private func knob(_ icon: String, size: CGFloat, cap: CGFloat, top: UInt32, bottom: UInt32) -> some View {
        ZStack {
            Circle().fill(LinearGradient(colors: [Color(hex: 0x363A45), Color(hex: 0x2A2D37)],
                                         startPoint: .top, endPoint: .bottom))
            Circle().fill(Color(hex: 0x16181D)).padding(size * 0.11)
            Circle()
                .fill(LinearGradient(colors: [Color(hex: top), Color(hex: bottom)], startPoint: .top, endPoint: .bottom))
                .overlay(Circle().stroke(Color.white.opacity(0.13), lineWidth: 1))
                .frame(width: cap, height: cap)
            Image(systemName: icon)
                .font(.system(size: cap * 0.36, weight: .bold))
                .foregroundColor(Color(hex: 0xA8ACB8))
        }
        .frame(width: size, height: size)
    }
}

// MARK: - Виджет

struct RadioWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: Shared.widgetKind, provider: RadioProvider()) { entry in
            RadioWidgetView(entry: entry)
        }
        .configurationDisplayName("RockRadioNet — плеер")
        .description("Обложка, исполнитель, песня и управление радио")
        .supportedFamilies([.systemMedium])
        .contentMarginsDisabled()
    }
}

@main
struct RockRadioNetWidgets: WidgetBundle {
    var body: some Widget {
        RadioWidget()
    }
}
