import AppIntents

/// Кнопки виджета. AudioPlaybackIntent выполняется в процессе приложения
/// (система при необходимости запускает его в фоне), поэтому звук управляется напрямую.

struct TogglePlayIntent: AudioPlaybackIntent {
    static let title: LocalizedStringResource = "Пуск или пауза"

    func perform() async throws -> some IntentResult {
        #if !WIDGET_EXT
        await MainActor.run { RadioController.shared.handle(.toggle) }
        #endif
        return .result()
    }
}

struct NextStationIntent: AudioPlaybackIntent {
    static let title: LocalizedStringResource = "Следующая станция"

    func perform() async throws -> some IntentResult {
        #if !WIDGET_EXT
        await MainActor.run { RadioController.shared.handle(.next) }
        #endif
        return .result()
    }
}

struct PrevStationIntent: AudioPlaybackIntent {
    static let title: LocalizedStringResource = "Предыдущая станция"

    func perform() async throws -> some IntentResult {
        #if !WIDGET_EXT
        await MainActor.run { RadioController.shared.handle(.prev) }
        #endif
        return .result()
    }
}

struct ReconnectIntent: AudioPlaybackIntent {
    static let title: LocalizedStringResource = "Переподключить поток"

    func perform() async throws -> some IntentResult {
        #if !WIDGET_EXT
        await MainActor.run { RadioController.shared.handle(.reconnect) }
        #endif
        return .result()
    }
}

struct ShuffleStationIntent: AudioPlaybackIntent {
    static let title: LocalizedStringResource = "Случайная станция"

    func perform() async throws -> some IntentResult {
        #if !WIDGET_EXT
        await MainActor.run { RadioController.shared.handle(.shuffle) }
        #endif
        return .result()
    }
}
