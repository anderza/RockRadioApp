import Foundation
import UIKit

/// Сетевые помощники: картинки и поиск обложек (iTunes, Deezer) — как в веб- и Android-версиях.
enum Net {
    private static let cache = NSCache<NSString, UIImage>()

    static func data(_ urlString: String, timeout: TimeInterval = 8) async -> Data? {
        guard let url = URL(string: urlString) else { return nil }
        var req = URLRequest(url: url, timeoutInterval: timeout)
        req.setValue("RockRadioNet/1.0 (iOS)", forHTTPHeaderField: "User-Agent")
        do {
            let (d, resp) = try await URLSession.shared.data(for: req)
            if let http = resp as? HTTPURLResponse, http.statusCode != 200 { return nil }
            return d
        } catch {
            return nil
        }
    }

    /// Картинка по ссылке (http/https или data:), уменьшенная до maxSide точек.
    static func image(_ urlString: String, maxSide: CGFloat = 400) async -> UIImage? {
        if urlString.isEmpty { return nil }
        if let c = cache.object(forKey: urlString as NSString) { return c }
        var bytes: Data?
        if urlString.hasPrefix("data:") {
            if let comma = urlString.firstIndex(of: ",") {
                bytes = Data(base64Encoded: String(urlString[urlString.index(after: comma)...]),
                             options: .ignoreUnknownCharacters)
            }
        } else {
            bytes = await data(urlString)
        }
        guard let b = bytes, let img = UIImage(data: b) else { return nil }
        let result = resized(img, maxSide: maxSide)
        cache.setObject(result, forKey: urlString as NSString)
        return result
    }

    static func resized(_ img: UIImage, maxSide: CGFloat) -> UIImage {
        let big = max(img.size.width, img.size.height)
        guard big > maxSide, big > 0 else { return img }
        let k = maxSide / big
        let size = CGSize(width: max(1, img.size.width * k), height: max(1, img.size.height * k))
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        return UIGraphicsImageRenderer(size: size, format: format).image { _ in
            img.draw(in: CGRect(origin: .zero, size: size))
        }
    }

    private static func norm(_ s: String) -> String {
        let lowered = s.lowercased()
        let mapped = lowered.unicodeScalars.map { CharacterSet.alphanumerics.contains($0) ? Character($0) : " " }
        return String(mapped).split(separator: " ").joined(separator: " ")
    }

    private static func similar(_ a: String, _ b: String) -> Bool {
        let x = norm(a), y = norm(b)
        if y.isEmpty { return true }
        if x.isEmpty { return false }
        return x.contains(y) || y.contains(x)
    }

    private static func json(_ urlString: String) async -> [String: Any]? {
        guard let d = await data(urlString) else { return nil }
        return (try? JSONSerialization.jsonObject(with: d)) as? [String: Any]
    }

    private static func enc(_ s: String) -> String {
        s.addingPercentEncoding(withAllowedCharacters: .alphanumerics) ?? ""
    }

    static func itunesCover(artist: String, title: String) async -> String? {
        let term = "\(artist) \(title)".trimmingCharacters(in: .whitespaces)
        if term.isEmpty { return nil }
        guard let j = await json("https://itunes.apple.com/search?media=music&entity=song&limit=5&term=" + enc(term)),
              let results = j["results"] as? [[String: Any]] else { return nil }
        for r in results {
            let xa = r["artistName"] as? String ?? ""
            let xt = r["trackName"] as? String ?? ""
            let art = r["artworkUrl100"] as? String ?? ""
            if (artist.isEmpty || similar(xa, artist)) && similar(xt, title) && !art.isEmpty {
                return art.replacingOccurrences(of: "100x100bb", with: "600x600bb")
            }
        }
        // точного совпадения нет — обложка любого трека этого исполнителя
        if !artist.isEmpty {
            for r in results {
                let xa = r["artistName"] as? String ?? ""
                let art = r["artworkUrl100"] as? String ?? ""
                if similar(xa, artist) && !art.isEmpty {
                    return art.replacingOccurrences(of: "100x100bb", with: "600x600bb")
                }
            }
        }
        return nil
    }

    private static func deezerOK(_ u: String) -> Bool {
        u.hasPrefix("http") && !u.contains("/artist//") && !u.contains("/cover//")
    }

    private static func deezerTrack(artist: String, title: String) async -> (album: String, artist: String) {
        let q = artist.isEmpty ? title : "artist:\"\(artist)\" track:\"\(title)\""
        guard let j = await json("https://api.deezer.com/search?limit=5&q=" + enc(q)),
              let data = j["data"] as? [[String: Any]] else { return ("", "") }
        var pick: [String: Any]?
        for r in data {
            let xa = (r["artist"] as? [String: Any])?["name"] as? String ?? ""
            let xt = r["title"] as? String ?? ""
            if (artist.isEmpty || similar(xa, artist)) && similar(xt, title) { pick = r; break }
        }
        if pick == nil && artist.isEmpty { pick = data.first }
        let album = (pick?["album"] as? [String: Any])?["cover_xl"] as? String ?? ""
        let pic = (pick?["artist"] as? [String: Any])?["picture_xl"] as? String ?? ""
        return (deezerOK(album) ? album : "", deezerOK(pic) ? pic : "")
    }

    private static func deezerArtist(_ artist: String) async -> String {
        if artist.isEmpty { return "" }
        guard let j = await json("https://api.deezer.com/search/artist?limit=3&q=" + enc(artist)),
              let data = j["data"] as? [[String: Any]] else { return "" }
        for r in data {
            let n = r["name"] as? String ?? ""
            let pic = r["picture_xl"] as? String ?? ""
            if similar(n, artist) && deezerOK(pic) { return pic }
        }
        return ""
    }

    /// mode = "album" — сначала обложка альбома, "artist" — сначала фото исполнителя.
    static func findCover(artist: String, title: String, mode: String) async -> String? {
        var dz: (album: String, artist: String)?
        func track() async -> (album: String, artist: String) {
            if let d = dz { return d }
            let d = await deezerTrack(artist: artist, title: title)
            dz = d
            return d
        }
        if mode == "artist" {
            let t = await track()
            if !t.artist.isEmpty { return t.artist }
            let a = await deezerArtist(artist)
            if !a.isEmpty { return a }
            if let i = await itunesCover(artist: artist, title: title) { return i }
            let t2 = await track()
            return t2.album.isEmpty ? nil : t2.album
        } else {
            if let i = await itunesCover(artist: artist, title: title) { return i }
            let t = await track()
            if !t.album.isEmpty { return t.album }
            if !t.artist.isEmpty { return t.artist }
            let a = await deezerArtist(artist)
            return a.isEmpty ? nil : a
        }
    }

    /// Похоже ли на ссылку на картинку (поле StreamUrl в потоке).
    static func looksLikeImage(_ u: String) -> Bool {
        guard u.hasPrefix("http"), let url = URL(string: u) else { return false }
        let path = url.path.lowercased()
        let exts = [".png", ".jpg", ".jpeg", ".webp", ".gif"]
        if exts.contains(where: { path.hasSuffix($0) }) { return true }
        return ["cover", "artwork", "albumart", "image", "img", "thumb"].contains(where: { path.contains($0) })
    }
}
