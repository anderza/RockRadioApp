import Foundation

/// Запись потока радио в файл (кнопка «Скачать трек»).
final class Recorder: NSObject, URLSessionDataDelegate {
    private var session: URLSession?
    private var task: URLSessionDataTask?
    private var handle: FileHandle?
    private var tmp: URL?
    private var name = ""
    private var ext = "mp3"
    private var finish: ((String, URL?) -> Void)?
    private(set) var running = false

    func start(url: String, name: String, ext: String, finish: @escaping (String, URL?) -> Void) {
        guard !running, let u = URL(string: url) else { return }
        running = true
        self.name = name
        self.ext = ext
        self.finish = finish
        let f = FileManager.default.temporaryDirectory
            .appendingPathComponent("rec_\(Int(Date().timeIntervalSince1970)).\(ext)")
        FileManager.default.createFile(atPath: f.path, contents: nil)
        handle = try? FileHandle(forWritingTo: f)
        tmp = f
        let s = URLSession(configuration: .default, delegate: self, delegateQueue: nil)
        session = s
        var req = URLRequest(url: u)
        req.setValue("RockRadioNet/1.0 (iOS)", forHTTPHeaderField: "User-Agent")
        task = s.dataTask(with: req)
        task?.resume()
    }

    func stop() {
        task?.cancel()
    }

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        handle?.write(data)
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        try? handle?.close()
        handle = nil
        running = false
        session.invalidateAndCancel()
        guard let t = tmp else { return }
        let size = (try? FileManager.default.attributesOfItem(atPath: t.path))?[.size] as? Int ?? 0
        if size == 0 {
            DispatchQueue.main.async { self.finish?("Не удалось записать поток", nil) }
            return
        }
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let safe = name.replacingOccurrences(of: "[\\\\/:*?\"<>|]", with: "_", options: .regularExpression)
        var dest = docs.appendingPathComponent("\(safe).\(ext)")
        if FileManager.default.fileExists(atPath: dest.path) {
            dest = docs.appendingPathComponent("\(safe) \(Int(Date().timeIntervalSince1970)).\(ext)")
        }
        do {
            try FileManager.default.moveItem(at: t, to: dest)
        } catch {
            DispatchQueue.main.async { self.finish?("Не удалось сохранить файл", nil) }
            return
        }
        DispatchQueue.main.async { self.finish?("Сохранено: \(dest.lastPathComponent)", dest) }
    }
}
