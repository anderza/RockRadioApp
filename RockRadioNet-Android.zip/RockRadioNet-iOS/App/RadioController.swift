import AVFoundation
import MediaPlayer
import UIKit
import WidgetKit

struct Station {
    let name: String
    let url: String
    let genre: String
    let logo: String
}

enum RadioAction {
    case toggle, play, pause, next, prev, reconnect, shuffle
}

/// Фоновое воспроизведение радио: AVPlayer, экран блокировки, гарнитура, метаданные потока, виджет.
final class RadioController: NSObject {
    static let shared = RadioController()

    private let player = AVPlayer()
    private let defaults = UserDefaults.standard
    private var isSetUp = false

    private(set) var stations: [Station] = []
    private(set) var index = -1

    private var wantPlay = false
    private var raw = ""
    private var artist = ""
    private var title = ""
    private var coverUrl = ""
    private var coverTries = 0
    private var cover: UIImage?
    private var logo: UIImage?
    private var logoFor = ""
    private var error = ""
    private var retries = 0
    private var startedAt: Date?

    private var statusObs: NSKeyValueObservation?
    private var itemObs: NSKeyValueObservation?
    private var stallWork: DispatchWorkItem?
    private var lastShared: Shared.State?

    /// Вызывается при любом изменении (для страницы).
    var onChange: (() -> Void)?

    // MARK: - Запуск

    func ensureSetUp() {
        if isSetUp { return }
        isSetUp = true

        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.playback, mode: .default, options: [])

        stations = loadStations()
        let saved = defaults.string(forKey: "current") ?? ""
        index = stations.firstIndex(where: { $0.url == saved }) ?? -1
        let vol = defaults.object(forKey: "volume") as? Float ?? 1
        player.volume = vol
        player.automaticallyWaitsToMinimizeStalling = true

        statusObs = player.observe(\.timeControlStatus, options: [.new]) { [weak self] _, _ in
            DispatchQueue.main.async { self?.notify() }
        }

        let nc = NotificationCenter.default
        nc.addObserver(self, selector: #selector(onInterruption(_:)),
                       name: AVAudioSession.interruptionNotification, object: session)
        nc.addObserver(self, selector: #selector(onRouteChange(_:)),
                       name: AVAudioSession.routeChangeNotification, object: session)
        nc.addObserver(self, selector: #selector(onStalled(_:)),
                       name: AVPlayerItem.playbackStalledNotification, object: nil)
        nc.addObserver(self, selector: #selector(onFailedToEnd(_:)),
                       name: AVPlayerItem.failedToPlayToEndTimeNotification, object: nil)
        nc.addObserver(self, selector: #selector(onFailedToEnd(_:)),
                       name: AVPlayerItem.didPlayToEndTimeNotification, object: nil)

        setupRemoteCommands()
        if index >= 0 { loadLogo(stations[index]) }
        notify()
    }

    private func setupRemoteCommands() {
        let c = MPRemoteCommandCenter.shared()
        c.playCommand.addTarget { [weak self] _ in self?.handle(.play); return .success }
        c.pauseCommand.addTarget { [weak self] _ in self?.handle(.pause); return .success }
        c.stopCommand.addTarget { [weak self] _ in self?.handle(.pause); return .success }
        c.togglePlayPauseCommand.addTarget { [weak self] _ in self?.handle(.toggle); return .success }
        c.nextTrackCommand.addTarget { [weak self] _ in self?.handle(.next); return .success }
        c.previousTrackCommand.addTarget { [weak self] _ in self?.handle(.prev); return .success }
        c.changePlaybackPositionCommand.isEnabled = false
        c.skipForwardCommand.isEnabled = false
        c.skipBackwardCommand.isEnabled = false
        c.seekForwardCommand.isEnabled = false
        c.seekBackwardCommand.isEnabled = false
    }

    // MARK: - Станции

    private func loadStations() -> [Station] {
        guard let raw = defaults.string(forKey: "stations"),
              let data = raw.data(using: .utf8),
              let arr = (try? JSONSerialization.jsonObject(with: data)) as? [[String: Any]] else { return [] }
        return arr.compactMap { o in
            let u = (o["u"] as? String ?? "").trimmingCharacters(in: .whitespaces)
            if u.isEmpty { return nil }
            let n = o["n"] as? String ?? ""
            return Station(name: n.isEmpty ? u : n, url: u, genre: o["g"] as? String ?? "", logo: o["l"] as? String ?? "")
        }
    }

    /// Новый список станций со страницы.
    func setStations(json: String) {
        if defaults.string(forKey: "stations") == json { return }
        defaults.set(json, forKey: "stations")
        let curUrl = stations.indices.contains(index) ? stations[index].url : (defaults.string(forKey: "current") ?? "")
        stations = loadStations()
        let ni = stations.firstIndex(where: { $0.url == curUrl }) ?? -1
        if ni < 0 && index >= 0 {
            index = -1
            stop()
            clearTrack()
        } else {
            index = ni
            if ni >= 0 { loadLogo(stations[ni]) }
        }
        notify()
    }

    func setVolume(_ v: Float) {
        let f = min(max(v, 0), 1)
        player.volume = f
        defaults.set(f, forKey: "volume")
    }

    func setCoverMode(_ mode: String) {
        let m = mode == "artist" ? "artist" : "album"
        if defaults.string(forKey: "coverMode") == m { return }
        defaults.set(m, forKey: "coverMode")
        if !title.isEmpty && (coverUrl.isEmpty || coverUrl.contains("mzstatic") || coverUrl.contains("dzcdn")) {
            coverUrl = ""
            cover = nil
            notify()
            searchCover()
        }
    }

    // MARK: - Управление

    func handle(_ action: RadioAction, index i: Int = -1) {
        ensureSetUp()
        switch action {
        case .toggle: wantPlay ? pause() : resume()
        case .play: if i >= 0 { play(i) } else { resume() }
        case .pause: pause()
        case .next: step(1)
        case .prev: step(-1)
        case .reconnect: if !stations.isEmpty { play(max(index, 0), keepTrack: true) }
        case .shuffle: shuffle()
        }
    }

    private func resume() {
        if stations.isEmpty { return }
        // живой эфир: подключаемся заново, чтобы не играть старый буфер
        play(index < 0 ? 0 : index, keepTrack: true)
    }

    private func pause() {
        wantPlay = false
        player.pause()
        notify()
    }

    private func stop() {
        wantPlay = false
        player.pause()
        player.replaceCurrentItem(with: nil)
    }

    private func step(_ d: Int) {
        if stations.isEmpty { return }
        play(index < 0 ? 0 : index + d)
    }

    private func shuffle() {
        let n = stations.count
        if n < 2 { resume(); return }
        var i = index
        while i == index { i = Int.random(in: 0..<n) }
        play(i)
    }

    func play(_ i: Int, keepTrack: Bool = false) {
        let n = stations.count
        if n == 0 { return }
        let ni = ((i % n) + n) % n
        let changed = ni != index
        index = ni
        let st = stations[ni]
        defaults.set(st.url, forKey: "current")
        retries = 0
        error = ""
        if changed || !keepTrack { clearTrack() }
        startedAt = Date()
        wantPlay = true
        guard let url = URL(string: st.url) else {
            error = "Неверная ссылка на поток"
            wantPlay = false
            notify()
            return
        }
        startItem(url)
        loadLogo(st)
        notify()
        DispatchQueue.main.asyncAfter(deadline: .now() + 13) { [weak self] in self?.notify() }
    }

    private func startItem(_ url: URL) {
        try? AVAudioSession.sharedInstance().setActive(true)
        let item = AVPlayerItem(url: url)
        let output = AVPlayerItemMetadataOutput(identifiers: nil)
        output.setDelegate(self, queue: .main)
        item.add(output)
        itemObs = item.observe(\.status, options: [.new]) { [weak self] it, _ in
            if it.status == .failed {
                DispatchQueue.main.async { self?.failed() }
            }
        }
        player.replaceCurrentItem(with: item)
        player.play()
    }

    private func failed() {
        guard wantPlay, stations.indices.contains(index) else { return }
        if retries < 3 {
            retries += 1
            error = "Переподключение (\(retries)/3)…"
            notify()
            let delay = 1.5 * Double(retries)
            DispatchQueue.main.asyncAfter(deadline: .now() + delay) { [weak self] in
                guard let self, self.wantPlay, self.stations.indices.contains(self.index),
                      let u = URL(string: self.stations[self.index].url) else { return }
                self.startItem(u)
            }
        } else {
            error = "Поток недоступен"
            wantPlay = false
            player.pause()
            notify()
        }
    }

    @objc private func onStalled(_ n: Notification) {
        guard (n.object as? AVPlayerItem) === player.currentItem else { return }
        stallWork?.cancel()
        let work = DispatchWorkItem { [weak self] in
            guard let self, self.wantPlay, self.player.timeControlStatus != .playing,
                  self.stations.indices.contains(self.index),
                  let u = URL(string: self.stations[self.index].url) else { return }
            self.startItem(u)
        }
        stallWork = work
        DispatchQueue.main.asyncAfter(deadline: .now() + 12, execute: work)
    }

    @objc private func onFailedToEnd(_ n: Notification) {
        guard (n.object as? AVPlayerItem) === player.currentItem else { return }
        DispatchQueue.main.async { self.failed() }
    }

    @objc private func onInterruption(_ n: Notification) {
        guard let info = n.userInfo,
              let raw = info[AVAudioSessionInterruptionTypeKey] as? UInt,
              let type = AVAudioSession.InterruptionType(rawValue: raw) else { return }
        if type == .ended {
            let optRaw = info[AVAudioSessionInterruptionOptionKey] as? UInt ?? 0
            if AVAudioSession.InterruptionOptions(rawValue: optRaw).contains(.shouldResume) && wantPlay {
                DispatchQueue.main.async { self.resume() }
            }
        }
        DispatchQueue.main.async { self.notify() }
    }

    @objc private func onRouteChange(_ n: Notification) {
        guard let raw = n.userInfo?[AVAudioSessionRouteChangeReasonKey] as? UInt,
              let reason = AVAudioSession.RouteChangeReason(rawValue: raw) else { return }
        if reason == .oldDeviceUnavailable {
            // отключили наушники — ставим на паузу
            DispatchQueue.main.async { self.pause() }
        }
    }

    // MARK: - Метаданные и картинки

    private func clearTrack() {
        raw = ""; artist = ""; title = ""; coverUrl = ""; cover = nil
    }

    private func loadLogo(_ st: Station) {
        if st.logo == logoFor && logo != nil { return }
        logoFor = st.logo
        logo = nil
        if st.logo.isEmpty { return }
        let key = st.logo
        Task {
            let img = await Net.image(key, maxSide: 300)
            await MainActor.run {
                if self.logoFor == key { self.logo = img; self.notify() }
            }
        }
    }

    fileprivate func onStreamTitle(_ t: String, streamUrl: String?) {
        let s = t.trimmingCharacters(in: .whitespacesAndNewlines)
        let img = (streamUrl ?? "").trimmingCharacters(in: .whitespaces)
        let streamImg = Net.looksLikeImage(img) ? img : ""
        if s == raw {
            if !streamImg.isEmpty && streamImg != coverUrl { loadCover(streamImg, key: s, searchIfFails: false) }
            return
        }
        raw = s
        if s.isEmpty {
            artist = ""; title = ""
        } else if let r = s.range(of: #"\s[-–—]\s"#, options: .regularExpression), r.lowerBound > s.startIndex {
            artist = String(s[..<r.lowerBound]).trimmingCharacters(in: .whitespaces)
            title = String(s[r.upperBound...]).trimmingCharacters(in: .whitespaces)
        } else {
            artist = ""; title = s
        }
        // пока ищем новую обложку, оставляем прежнюю (артист/альбом), а не логотип станции
        if title.isEmpty { coverUrl = ""; cover = nil }
        notify()
        coverTries = 0
        if !streamImg.isEmpty {
            loadCover(streamImg, key: raw, searchIfFails: true)
        } else if !title.isEmpty {
            searchCover()
        }
    }

    private func searchCover() {
        if title.isEmpty { return }
        let a = artist, t = title, key = raw
        let mode = defaults.string(forKey: "coverMode") ?? "album"
        Task {
            let url = await Net.findCover(artist: a, title: t, mode: mode)
            await MainActor.run {
                if let url, self.raw == key { self.loadCover(url, key: key, searchIfFails: false) }
                else if url == nil, self.raw == key, self.coverTries < 2 {
                    self.coverTries += 1
                    DispatchQueue.main.asyncAfter(deadline: .now() + 15) { if self.raw == key { self.searchCover() } }
                }
            }
        }
    }

    private func loadCover(_ url: String, key: String, searchIfFails: Bool) {
        Task {
            let img = await Net.image(url, maxSide: 500)
            await MainActor.run {
                guard self.raw == key else { return }
                if let img {
                    self.coverUrl = url
                    self.cover = img
                    self.notify()
                } else if searchIfFails {
                    self.searchCover()
                }
            }
        }
    }

    // MARK: - Состояние

    var isPlaying: Bool { wantPlay }

    func stateJSON() -> String {
        let since = startedAt.map { Int(Date().timeIntervalSince($0)) } ?? 0
        let obj: [String: Any] = [
            "index": index,
            "playing": wantPlay,
            "buffering": player.timeControlStatus == .waitingToPlayAtSpecifiedRate,
            "raw": raw,
            "artist": artist,
            "title": title,
            "cover": coverUrl,
            "error": error,
            "since": since
        ]
        guard let d = try? JSONSerialization.data(withJSONObject: obj),
              let s = String(data: d, encoding: .utf8) else { return "null" }
        return s
    }

    func notify() {
        updateNowPlaying()
        updateWidget()
        onChange?()
    }

    private func updateNowPlaying() {
        let center = MPNowPlayingInfoCenter.default()
        guard stations.indices.contains(index) else { center.nowPlayingInfo = nil; return }
        let st = stations[index]
        let hasTrack = !title.isEmpty
        var info: [String: Any] = [
            MPMediaItemPropertyTitle: hasTrack ? title : st.name,
            MPMediaItemPropertyArtist: hasTrack ? (artist.isEmpty ? st.name : artist)
                                                : (st.genre.isEmpty ? "Интернет-радио" : st.genre),
            MPMediaItemPropertyAlbumTitle: st.name,
            MPNowPlayingInfoPropertyIsLiveStream: true,
            MPNowPlayingInfoPropertyPlaybackRate: wantPlay ? 1.0 : 0.0
        ]
        if let img = cover ?? logo {
            info[MPMediaItemPropertyArtwork] = MPMediaItemArtwork(boundsSize: img.size) { _ in img }
        }
        center.nowPlayingInfo = info
    }

    private func updateWidget() {
        let st = stations.indices.contains(index) ? stations[index] : nil
        let img = cover ?? logo
        let stamp = img == nil ? "" : (coverUrl.isEmpty ? "logo:" + logoFor : coverUrl)
        let s = Shared.State(
            hasStations: !stations.isEmpty,
            hasCurrent: st != nil,
            name: st?.name ?? "",
            genre: st?.genre ?? "",
            artist: artist,
            title: title,
            playing: wantPlay,
            error: error,
            coverStamp: stamp
        )
        if s == lastShared { return }
        if s.coverStamp != lastShared?.coverStamp, let file = Shared.coverFile {
            if let img, let jpg = Net.resized(img, maxSide: 300).jpegData(compressionQuality: 0.85) {
                try? jpg.write(to: file, options: .atomic)
            } else {
                try? FileManager.default.removeItem(at: file)
            }
        }
        lastShared = s
        Shared.save(s)
        WidgetCenter.shared.reloadTimelines(ofKind: Shared.widgetKind)
    }
}

extension RadioController: AVPlayerItemMetadataOutputPushDelegate {
    func metadataOutput(_ output: AVPlayerItemMetadataOutput,
                        didOutputTimedMetadataGroups groups: [AVTimedMetadataGroup],
                        from track: AVPlayerItemTrack?) {
        var streamTitle: String?
        var streamUrl: String?
        for group in groups {
            for item in group.items {
                if item.identifier == .icyMetadataStreamTitle {
                    streamTitle = item.stringValue
                } else if item.identifier == .icyMetadataStreamURL {
                    streamUrl = item.stringValue
                } else if streamTitle == nil, item.commonKey == .commonKeyTitle {
                    streamTitle = item.stringValue
                }
            }
        }
        if let t = streamTitle { onStreamTitle(t, streamUrl: streamUrl) }
    }
}
