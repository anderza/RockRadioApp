package com.rockradionet.player

import android.Manifest
import android.annotation.SuppressLint
import android.app.UiModeManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.InputStream

/**
 * Окно приложения: тот же интерфейс, что и HTML-версия (assets/www/index.html),
 * а звук, фон и виджет обслуживает RadioService.
 */
class MainActivity : ComponentActivity() {

    companion object {
        private const val HOST = "appassets.androidplatform.net"
        private const val START = "https://$HOST/assets/www/index.html"
        private val PLAYER_HOSTS = listOf(
            "spotify.com", "scdn.co", "yandex.ru", "yandex.net", "yandex.com", "yandex.by", "yandex.kz",
            "youtube.com", "youtube-nocookie.com", "googlevideo.com", "ytimg.com",
            "vk.com", "vk.ru"
        )
    }

    private lateinit var web: WebView
    private lateinit var recorder: Recorder
    private val main = Handler(Looper.getMainLooper())
    @Volatile
    private var lastStations: String? = null
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var pendingText: String? = null

    private val stateListener: () -> Unit = { main.post { pushState() } }

    private val pickFile = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res.resultCode, res.data))
        fileCallback = null
    }

    private val saveDocument = registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        val text = pendingText
        pendingText = null
        if (uri != null && text != null) {
            try {
                contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                Toast.makeText(this, "Файл сохранён", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Не удалось сохранить файл", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private val askNotifications = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    // Раздел «Папки»: выбор папки с музыкой (доступ к ней запоминается) и отдельных файлов
    private val pickTree = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { tree ->
        if (tree != null) {
            keepAccess(tree)
            Toast.makeText(this, "Ищу музыку в папке…", Toast.LENGTH_SHORT).show()
            Thread {
                val json = try { scanTree(tree) } catch (e: Exception) { "[]" }
                main.post { sendFolders(json) }
            }.start()
        }
    }

    private val pickAudios = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            val tracks = JSONArray()
            for (u in uris) {
                keepAccess(u)
                tracks.put(JSONObject().put("n", displayName(u)).put("u", u.toString()))
            }
            val folder = JSONObject().put("name", "Выбранные файлы").put("key", "files").put("tracks", tracks)
            sendFolders(JSONArray().put(folder).toString())
        }
    }

    // после закрытия окна входа страница обновляет встроенный плеер плейлиста
    private val loginResult = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        web.evaluateJavascript("window.nativeLoginDone&&window.nativeLoginDone()", null)
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#12141C")
        window.navigationBarColor = Color.parseColor("#22252E")

        val assets = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        recorder = Recorder(applicationContext)
        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#12141C"))
        // Полосы прокрутки не показываем (прокрутка пальцем работает как раньше)
        web.isVerticalScrollBarEnabled = false
        web.isHorizontalScrollBarEnabled = false
        setContentView(web)

        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW // http-логотипы станций
            allowFileAccess = false
            allowContentAccess = false
        }
        // вход в аккаунт Яндекс Музыки / YouTube / Spotify внутри встроенного плеера плейлистов
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(web, true)
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val u = request.url
                if (u.host == HOST && u.path == "/local/art") return localArt(request)
                if (u.host == HOST && (u.path ?: "").startsWith("/local/")) return localFile(request)
                return assets.shouldInterceptRequest(u)
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (!request.isForMainFrame) return false // переходы внутри встроенного плеера плейлистов
                if (request.url.host == HOST) return false
                openExternal(request.url.toString())
                return true
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            // Защищённое воспроизведение (DRM) для встроенных плееров Spotify / Яндекс Музыки / YouTube
            override fun onPermissionRequest(request: PermissionRequest) {
                val host = request.origin.host.orEmpty()
                val trusted = PLAYER_HOSTS.any { host == it || host.endsWith(".$it") }
                val drm = request.resources.filter { it == PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID }
                if (trusted && drm.isNotEmpty()) request.grant(drm.toTypedArray()) else request.deny()
            }

            override fun onShowFileChooser(
                view: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                val accept = params.acceptTypes.flatMap { it.split(',') }.map { it.trim() }
                val mime = if (accept.any { it.startsWith("image/") }) "image/*" else "*/*"
                val pick = Intent(Intent.ACTION_GET_CONTENT)
                    .addCategory(Intent.CATEGORY_OPENABLE)
                    .setType(mime)
                return try {
                    pickFile.launch(Intent.createChooser(pick, null))
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    false
                }
            }
        }

        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl(START)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // Сначала закрываем проигрыватель/меню/раздел на странице, иначе сворачиваем приложение
                // (радио продолжает играть).
                // На Android TV двойное «Назад» открывает на странице окно «Закрыть плеер?».
                web.evaluateJavascript("window.rrnBack?rrnBack():((window.goBack&&goBack())?1:0)") { r ->
                    if (r != "1") moveTaskToBack(true)
                }
            }
        })

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    /** Приложение уже открыто, и его снова запустили значком с рабочего стола — показываем главный экран со станциями */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.action == Intent.ACTION_MAIN && intent.hasCategory(Intent.CATEGORY_LAUNCHER) && ::web.isInitialized) {
            web.evaluateJavascript("window.rrnHome&&rrnHome()", null)
        }
    }

    override fun onStart() {
        super.onStart()
        RadioService.listeners.add(stateListener)
        pushState()
    }

    override fun onStop() {
        RadioService.listeners.remove(stateListener)
        super.onStop()
    }

    override fun onDestroy() {
        web.removeJavascriptInterface("Android")
        web.destroy()
        super.onDestroy()
    }

    private fun stateJson(): String = RadioService.stateJson.ifEmpty {
        val list = Store.stations(this)
        val url = Store.currentUrl(this)
        JSONObject().apply {
            put("index", list.indexOfFirst { it.url == url })
            put("playing", false)
            put("raw", "")
            put("since", 0)
        }.toString()
    }

    private fun pushState() {
        if (!::web.isInitialized) return
        web.evaluateJavascript("window.nativeState&&window.nativeState(${stateJson()})", null)
    }

    private fun openExternal(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            Toast.makeText(this, "Нет приложения для открытия ссылки", Toast.LENGTH_SHORT).show()
        }
    }

    /** Команда сервису: напрямую, если он запущен, иначе запуском сервиса. */
    private fun command(action: String, index: Int = -1) {
        main.post {
            val svc = RadioService.instance
            if (svc != null) {
                svc.handle(action, index)
            } else if (action != RadioService.A_PAUSE) {
                try {
                    startService(
                        Intent(this, RadioService::class.java)
                            .setAction(action)
                            .putExtra(RadioService.EXTRA_INDEX, index)
                    )
                } catch (e: Exception) {
                    Toast.makeText(this, "Не удалось запустить воспроизведение", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    // ===== Раздел «Папки»: своя музыка на устройстве =====

    private fun keepAccess(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) {
        }
    }

    private fun sendFolders(json: String) {
        if (!::web.isInitialized) return
        web.evaluateJavascript("window.nativeFolders&&window.nativeFolders(" + JSONObject.quote(json) + ")", null)
    }

    private fun displayName(u: Uri): String {
        try {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val n = c.getString(0)
                    if (!n.isNullOrBlank()) return n
                }
            }
        } catch (e: Exception) {
        }
        return (u.lastPathSegment ?: "Файл").substringAfterLast('/')
    }

    private val audioExt = Regex("\\.(mp3|m4a|aac|ogg|oga|opus|flac|wav|wma|webm|mka|aif|aiff|amr|3gp)$", RegexOption.IGNORE_CASE)
    private val coverName = Regex("^(cover|folder|front|albumart[^/]*)\\.(jpe?g|png|webp)$", RegexOption.IGNORE_CASE)
    private val imageExt = Regex("\\.(jpe?g|png|webp)$", RegexOption.IGNORE_CASE)

    /** Обходит выбранную папку и вложенные, собирает музыку по папкам: [{name, key, cover, tracks:[{n,u}]}] */
    private fun scanTree(tree: Uri): String {
        val out = JSONArray()
        val rootId = DocumentsContract.getTreeDocumentId(tree)
        var count = 0
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )

        fun walk(docId: String, name: String, path: String, depth: Int) {
            if (depth > 8 || count > 5000) return
            val tracks = JSONArray()
            var cover: String? = null
            var anyImage: String? = null // если нет cover.jpg / folder.jpg — любая картинка из папки
            val dirs = ArrayList<Pair<String, String>>()
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            contentResolver.query(children, cols, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getString(0) ?: continue
                    val n = c.getString(1) ?: ""
                    val mime = c.getString(2) ?: ""
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        dirs.add(Pair(id, n))
                    } else if (mime.startsWith("audio/") || audioExt.containsMatchIn(n)) {
                        val du = DocumentsContract.buildDocumentUriUsingTree(tree, id)
                        tracks.put(JSONObject().put("n", n).put("u", du.toString()))
                        count++
                    } else if (cover == null && coverName.matches(n)) {
                        cover = DocumentsContract.buildDocumentUriUsingTree(tree, id).toString()
                    } else if (anyImage == null && (mime.startsWith("image/") || imageExt.containsMatchIn(n))) {
                        anyImage = DocumentsContract.buildDocumentUriUsingTree(tree, id).toString()
                    }
                }
            }
            if (tracks.length() > 0) {
                val f = JSONObject().put("name", name).put("key", path).put("tracks", tracks)
                val cv = cover ?: anyImage
                if (cv != null) f.put("cover", cv)
                out.put(f)
            }
            for (d in dirs.sortedBy { it.second.lowercase() }) walk(d.first, d.second, path + "/" + d.second, depth + 1)
        }

        val top = rootName(tree, rootId)
        walk(rootId, top, tree.toString(), 0)
        return out.toString()
    }

    private fun rootName(tree: Uri, id: String): String {
        try {
            val u = DocumentsContract.buildDocumentUriUsingTree(tree, id)
            contentResolver.query(u, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val n = c.getString(0)
                    if (!n.isNullOrBlank()) return n
                }
            }
        } catch (e: Exception) {
        }
        return id.substringAfterLast(':').substringAfterLast('/').ifEmpty { "Музыка" }
    }

    /** Файл можно отдавать, только если пользователь сам дал к нему (или к его папке) доступ */
    private fun allowed(uri: Uri): Boolean {
        val s = uri.toString()
        return contentResolver.persistedUriPermissions.any { p ->
            val t = p.uri.toString()
            p.isReadPermission && (s == t || s.startsWith("$t/"))
        }
    }

    private fun emptyResponse(code: Int, reason: String): WebResourceResponse =
        WebResourceResponse("text/plain", "utf-8", code, reason, emptyMap(), ByteArrayInputStream(ByteArray(0)))

    /** Отдаёт странице свой музыкальный файл по адресу /local/f?u=content://… (с перемоткой — заголовок Range) */
    private fun localFile(req: WebResourceRequest): WebResourceResponse {
        val s = req.url.getQueryParameter("u")
        if (s.isNullOrEmpty()) return emptyResponse(404, "Not Found")
        val uri = Uri.parse(s)
        if (uri.scheme != "content" || !allowed(uri)) return emptyResponse(403, "Forbidden")
        return try {
            val afd = contentResolver.openAssetFileDescriptor(uri, "r") ?: return emptyResponse(404, "Not Found")
            val total = afd.length
            val mime = contentResolver.getType(uri) ?: "audio/mpeg"
            val input: InputStream = afd.createInputStream()
            val range = req.requestHeaders.entries.firstOrNull { it.key.equals("Range", true) }?.value
            val m = if (range != null && total > 0) Regex("bytes=(\\d*)-(\\d*)").find(range) else null
            if (m != null) {
                var start = m.groupValues[1].toLongOrNull() ?: 0L
                var end = m.groupValues[2].toLongOrNull() ?: (total - 1)
                if (m.groupValues[1].isEmpty()) {
                    start = maxOf(0L, total - end)
                    end = total - 1
                }
                if (end >= total) end = total - 1
                if (start > end) {
                    input.close()
                    return emptyResponse(416, "Range Not Satisfiable")
                }
                skipFully(input, start)
                val len = end - start + 1
                val headers = HashMap<String, String>()
                headers["Content-Range"] = "bytes $start-$end/$total"
                headers["Accept-Ranges"] = "bytes"
                headers["Content-Length"] = len.toString()
                WebResourceResponse(mime, null, 206, "Partial Content", headers, Limited(input, len))
            } else {
                val headers = HashMap<String, String>()
                headers["Accept-Ranges"] = "bytes"
                if (total > 0) headers["Content-Length"] = total.toString()
                WebResourceResponse(mime, null, 200, "OK", headers, input)
            }
        } catch (e: Exception) {
            emptyResponse(404, "Not Found")
        }
    }

    /** Встроенная обложка трека: /local/art?u=content://… — Android сам читает теги любого формата (mp3, m4a, flac, ogg…) */
    private fun localArt(req: WebResourceRequest): WebResourceResponse {
        val s = req.url.getQueryParameter("u")
        if (s.isNullOrEmpty()) return emptyResponse(404, "Not Found")
        val uri = Uri.parse(s)
        if (uri.scheme != "content" || !allowed(uri)) return emptyResponse(403, "Forbidden")
        val mmr = MediaMetadataRetriever()
        return try {
            mmr.setDataSource(this, uri)
            val pic = mmr.embeddedPicture
            if (pic == null || pic.size < 100) {
                emptyResponse(404, "Not Found")
            } else {
                val png = pic[0] == 0x89.toByte() && pic[1] == 0x50.toByte()
                val headers = HashMap<String, String>()
                headers["Cache-Control"] = "max-age=86400"
                WebResourceResponse(if (png) "image/png" else "image/jpeg", null, 200, "OK", headers, ByteArrayInputStream(pic))
            }
        } catch (e: Exception) {
            emptyResponse(404, "Not Found")
        } finally {
            try {
                mmr.release()
            } catch (e: Exception) {
            }
        }
    }

    private fun skipFully(input: InputStream, n: Long) {
        var left = n
        while (left > 0) {
            val k = input.skip(left)
            if (k > 0) {
                left -= k
            } else {
                if (input.read() < 0) break
                left--
            }
        }
    }

    /** Поток, который отдаёт не больше len байт (для ответа на Range) */
    private class Limited(private val src: InputStream, private var left: Long) : InputStream() {
        override fun read(): Int {
            if (left <= 0) return -1
            val r = src.read()
            if (r >= 0) left--
            return r
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (left <= 0) return -1
            val n = src.read(b, off, minOf(len.toLong(), left).toInt())
            if (n > 0) left -= n
            return n
        }

        override fun close() = src.close()
    }

    /** Методы, доступные странице как window.Android. Вызываются не в главном потоке. */
    inner class Bridge {
        @JavascriptInterface
        fun isNative(): Boolean = true

        /** Уровни 24 полос эквалайзера для того, что сейчас звучит по радио ("" — тишина) */
        @JavascriptInterface
        fun eqLevels(): String = EqMeter.snapshot()

        @JavascriptInterface
        fun isTv(): Boolean =
            (getSystemService(Context.UI_MODE_SERVICE) as UiModeManager).currentModeType ==
                Configuration.UI_MODE_TYPE_TELEVISION

        @JavascriptInterface
        fun getState(): String = stateJson()

        @JavascriptInterface
        fun setStations(json: String) {
            if (json == lastStations) return
            lastStations = json
            Store.saveStations(this@MainActivity, json)
            main.post {
                val svc = RadioService.instance
                if (svc != null) svc.reloadStations() else Widget.update(this@MainActivity)
            }
        }

        @JavascriptInterface
        fun play(index: Int) = command(RadioService.A_PLAY, index)

        @JavascriptInterface
        fun pause() = command(RadioService.A_PAUSE)

        /** «Папки»: системное окно выбора папки с музыкой */
        @JavascriptInterface
        fun pickFolder() {
            main.post {
                try {
                    pickTree.launch(null)
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "На этом устройстве нет окна выбора папок — выберите файлы", Toast.LENGTH_LONG).show()
                }
            }
        }

        /** «Папки»: системное окно выбора музыкальных файлов (можно несколько) */
        @JavascriptInterface
        fun pickAudio() {
            main.post {
                try {
                    pickAudios.launch(arrayOf("audio/*"))
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Не удалось открыть выбор файлов", Toast.LENGTH_LONG).show()
                }
            }
        }

        /** Свернуть приложение (радио продолжает играть). */
        @JavascriptInterface
        fun minimize() {
            main.post { moveTaskToBack(true) }
        }

        /** Окно «Закрыть плеер?» → «Закрыть»: звук останавливается, служба и приложение закрываются. */
        @JavascriptInterface
        fun exitApp() {
            main.post {
                try {
                    recorder.stop()
                } catch (e: Exception) {
                }
                RadioService.instance?.shutdown()
                stopService(Intent(this@MainActivity, RadioService::class.java))
                finishAndRemoveTask()
            }
        }

        @JavascriptInterface
        fun toggle() = command(RadioService.A_TOGGLE)

        @JavascriptInterface
        fun next() = command(RadioService.A_NEXT)

        @JavascriptInterface
        fun prev() = command(RadioService.A_PREV)

        @JavascriptInterface
        fun setVolume(v: Double) {
            val f = v.toFloat().coerceIn(0f, 1f)
            Store.saveVolume(this@MainActivity, f)
            main.post { RadioService.instance?.setVolume(f) }
        }

        /** Ориентация экрана: "auto", "portrait" или "landscape". */
        @JavascriptInterface
        fun setOrientation(mode: String) {
            main.post {
                requestedOrientation = when (mode) {
                    "portrait" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                    "landscape" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                }
            }
        }

        @JavascriptInterface
        fun setCoverMode(mode: String) {
            if (mode == Store.coverMode(this@MainActivity)) return
            Store.saveCoverMode(this@MainActivity, mode)
            main.post { RadioService.instance?.refetchCover() }
        }

        @JavascriptInterface
        fun openUrl(url: String) {
            main.post { openExternal(url) }
        }

        /** Вход в аккаунт Яндекс Музыки / Spotify в отдельном окне с общими cookie. */
        @JavascriptInterface
        fun openLogin(url: String, title: String) {
            main.post {
                try {
                    loginResult.launch(
                        Intent(this@MainActivity, LoginActivity::class.java)
                            .putExtra("url", url)
                            .putExtra("title", title)
                    )
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Не удалось открыть окно входа", Toast.LENGTH_SHORT).show()
                }
            }
        }

        /** Запись потока в файл (кнопка «Скачать трек»). */
        @JavascriptInterface
        fun startRecord(url: String, name: String, ext: String) {
            recorder.start(url, name, ext) { msg ->
                main.post { web.evaluateJavascript("window.nativeRec&&window.nativeRec(" + JSONObject.quote(msg) + ")", null) }
            }
        }

        @JavascriptInterface
        fun stopRecord() = recorder.stop()

        @JavascriptInterface
        fun saveText(name: String, text: String) {
            main.post {
                pendingText = text
                try {
                    saveDocument.launch(name)
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Не удалось сохранить файл", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
