package com.rockradionet.player

import android.Manifest
import android.annotation.SuppressLint
import android.app.UiModeManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject

/**
 * Окно приложения: тот же интерфейс, что и HTML-версия (assets/www/index.html),
 * а звук, фон и виджет обслуживает RadioService.
 */
class MainActivity : ComponentActivity() {

    companion object {
        private const val HOST = "appassets.androidplatform.net"
        private const val START = "https://$HOST/assets/www/index.html"
    }

    private lateinit var web: WebView
    private lateinit var recorder: Recorder
    private val main = Handler(Looper.getMainLooper())
    @Volatile
    private var lastStations: String? = null
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var pendingText: String? = null

    private val stateListener: () -> Unit = { main.post { pushState() } }

    private val pickFile = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res.resultCode, res.data))
        fileCallback = null
    }

    private val saveDocument = registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        val text = pendingText
        pendingText = null
        if (uri != null && text != null) {
            try {
                contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                Toast.makeText(this, "Файл сохранён", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Не удалось сохранить файл", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private val askNotifications = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#12141C")
        window.navigationBarColor = Color.parseColor("#22252E")

        val assets = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        recorder = Recorder(applicationContext)
        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#12141C"))
        setContentView(web)

        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW // http-логотипы станций
            allowFileAccess = false
            allowContentAccess = false
        }
        // вход в аккаунт Яндекс Музыки / YouTube / Spotify внутри встроенного плеера плейлистов
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(web, true)
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                assets.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (!request.isForMainFrame) return false // переходы внутри встроенного плеера плейлистов
                if (request.url.host == HOST) return false
                openExternal(request.url.toString())
                return true
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                val accept = params.acceptTypes.flatMap { it.split(',') }.map { it.trim() }
                val mime = if (accept.any { it.startsWith("image/") }) "image/*" else "*/*"
                val pick = Intent(Intent.ACTION_GET_CONTENT)
                    .addCategory(Intent.CATEGORY_OPENABLE)
                    .setType(mime)
                return try {
                    pickFile.launch(Intent.createChooser(pick, null))
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    false
                }
            }
        }

        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl(START)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // Сначала закрываем проигрыватель/меню/раздел на странице, иначе сворачиваем приложение
                // (радио продолжает играть).
                web.evaluateJavascript("(window.goBack&&goBack())?1:0") { r ->
                    if (r != "1") moveTaskToBack(true)
                }
            }
        })

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onStart() {
        super.onStart()
        RadioService.listeners.add(stateListener)
        pushState()
    }

    override fun onStop() {
        RadioService.listeners.remove(stateListener)
        super.onStop()
    }

    override fun onDestroy() {
        web.removeJavascriptInterface("Android")
        web.destroy()
        super.onDestroy()
    }

    private fun stateJson(): String = RadioService.stateJson.ifEmpty {
        val list = Store.stations(this)
        val url = Store.currentUrl(this)
        JSONObject().apply {
            put("index", list.indexOfFirst { it.url == url })
            put("playing", false)
            put("raw", "")
            put("since", 0)
        }.toString()
    }

    private fun pushState() {
        if (!::web.isInitialized) return
        web.evaluateJavascript("window.nativeState&&window.nativeState(${stateJson()})", null)
    }

    private fun openExternal(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            Toast.makeText(this, "Нет приложения для открытия ссылки", Toast.LENGTH_SHORT).show()
        }
    }

    /** Команда сервису: напрямую, если он запущен, иначе запуском сервиса. */
    private fun command(action: String, index: Int = -1) {
        main.post {
            val svc = RadioService.instance
            if (svc != null) {
                svc.handle(action, index)
            } else if (action != RadioService.A_PAUSE) {
                try {
                    startService(
                        Intent(this, RadioService::class.java)
                            .setAction(action)
                            .putExtra(RadioService.EXTRA_INDEX, index)
                    )
                } catch (e: Exception) {
                    Toast.makeText(this, "Не удалось запустить воспроизведение", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    /** Методы, доступные странице как window.Android. Вызываются не в главном потоке. */
    inner class Bridge {
        @JavascriptInterface
        fun isNative(): Boolean = true

        @JavascriptInterface
        fun isTv(): Boolean =
            (getSystemService(Context.UI_MODE_SERVICE) as UiModeManager).currentModeType ==
                Configuration.UI_MODE_TYPE_TELEVISION

        @JavascriptInterface
        fun getState(): String = stateJson()

        @JavascriptInterface
        fun setStations(json: String) {
            if (json == lastStations) return
            lastStations = json
            Store.saveStations(this@MainActivity, json)
            main.post {
                val svc = RadioService.instance
                if (svc != null) svc.reloadStations() else Widget.update(this@MainActivity)
            }
        }

        @JavascriptInterface
        fun play(index: Int) = command(RadioService.A_PLAY, index)

        @JavascriptInterface
        fun pause() = command(RadioService.A_PAUSE)

        @JavascriptInterface
        fun toggle() = command(RadioService.A_TOGGLE)

        @JavascriptInterface
        fun next() = command(RadioService.A_NEXT)

        @JavascriptInterface
        fun prev() = command(RadioService.A_PREV)

        @JavascriptInterface
        fun setVolume(v: Double) {
            val f = v.toFloat().coerceIn(0f, 1f)
            Store.saveVolume(this@MainActivity, f)
            main.post { RadioService.instance?.setVolume(f) }
        }

        /** Ориентация экрана: "auto", "portrait" или "landscape". */
        @JavascriptInterface
        fun setOrientation(mode: String) {
            main.post {
                requestedOrientation = when (mode) {
                    "portrait" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                    "landscape" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                }
            }
        }

        @JavascriptInterface
        fun setCoverMode(mode: String) {
            if (mode == Store.coverMode(this@MainActivity)) return
            Store.saveCoverMode(this@MainActivity, mode)
            main.post { RadioService.instance?.refetchCover() }
        }

        @JavascriptInterface
        fun openUrl(url: String) {
            main.post { openExternal(url) }
        }

        /** Запись потока в файл (кнопка «Скачать трек»). */
        @JavascriptInterface
        fun startRecord(url: String, name: String, ext: String) {
            recorder.start(url, name, ext) { msg ->
                main.post { web.evaluateJavascript("window.nativeRec&&window.nativeRec(" + JSONObject.quote(msg) + ")", null) }
            }
        }

        @JavascriptInterface
        fun stopRecord() = recorder.stop()

        @JavascriptInterface
        fun saveText(name: String, text: String) {
            main.post {
                pendingText = text
                try {
                    saveDocument.launch(name)
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Не удалось сохранить файл", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
