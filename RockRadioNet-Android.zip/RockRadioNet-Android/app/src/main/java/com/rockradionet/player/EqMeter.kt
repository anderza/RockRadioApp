package com.rockradionet.player

import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.audio.TeeAudioProcessor
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Эквалайзер на странице: копия звука, который играет радио (после декодирования, до громкости),
 * раскладывается на 24 полосы частот (40 Гц … 16 кГц). Тишина — все полосы 0.
 * Звук попадает сюда немного раньше, чем в динамик (буфер вывода), поэтому уровни отдаются с задержкой DELAY_MS.
 */
@OptIn(UnstableApi::class)
object EqMeter : TeeAudioProcessor.AudioBufferSink {
    const val BANDS = 24
    private const val N = 1024
    private const val DELAY_MS = 300L
    private const val EVERY_MS = 33L

    private val window = FloatArray(N) { (0.5 - 0.5 * cos(2 * PI * it / (N - 1))).toFloat() }
    private val ring = FloatArray(N)
    private val re = FloatArray(N)
    private val im = FloatArray(N)
    private var pos = 0
    private var filled = 0
    private var rate = 44100
    private var channels = 2
    private var encoding = C.ENCODING_PCM_16BIT
    private var lastCalc = 0L

    private class Frame(val time: Long, val levels: IntArray)

    private val history = ArrayDeque<Frame>()

    override fun flush(sampleRateHz: Int, channelCount: Int, encoding: Int) {
        rate = if (sampleRateHz > 0) sampleRateHz else 44100
        channels = max(1, channelCount)
        this.encoding = encoding
        pos = 0
        filled = 0
    }

    override fun handleBuffer(buffer: ByteBuffer) {
        val b = buffer.duplicate().order(ByteOrder.nativeOrder())
        when (encoding) {
            C.ENCODING_PCM_16BIT -> {
                val frame = 2 * channels
                while (b.remaining() >= frame) {
                    var s = 0f
                    for (c in 0 until channels) s += b.short / 32768f
                    push(s / channels)
                }
            }
            C.ENCODING_PCM_FLOAT -> {
                val frame = 4 * channels
                while (b.remaining() >= frame) {
                    var s = 0f
                    for (c in 0 until channels) s += b.float
                    push(s / channels)
                }
            }
            else -> return
        }
        val now = System.currentTimeMillis()
        if (filled >= N && now - lastCalc >= EVERY_MS) {
            lastCalc = now
            val lv = spectrum()
            synchronized(history) {
                history.addLast(Frame(now, lv))
                while (history.size > 60) history.removeFirst()
            }
        }
    }

    private fun push(v: Float) {
        ring[pos] = v
        pos = (pos + 1) % N
        if (filled < N) filled++
    }

    /** Уровни полос 0…100 (по-децибельно, −60 дБ … 0 дБ) */
    private fun spectrum(): IntArray {
        for (i in 0 until N) {
            re[i] = ring[(pos + i) % N] * window[i]
            im[i] = 0f
        }
        fft()
        val out = IntArray(BANDS)
        val lo = 40.0
        val hi = min(16000.0, rate / 2.0)
        for (k in 0 until BANDS) {
            val f1 = lo * (hi / lo).pow(k.toDouble() / BANDS)
            val f2 = lo * (hi / lo).pow((k + 1).toDouble() / BANDS)
            val b1 = max(1, (f1 * N / rate).toInt())
            val b2 = max(b1 + 1, min(N / 2, (f2 * N / rate).toInt() + 1))
            var m = 0f
            for (i in b1 until b2) m = max(m, sqrt(re[i] * re[i] + im[i] * im[i]))
            // синус на полной громкости даёт |X| ≈ N/4
            val db = 20 * log10(m / (N / 4f) + 1e-9f)
            out[k] = (((db + 60f) / 60f).coerceIn(0f, 1f) * 100).toInt()
        }
        return out
    }

    private fun fft() {
        var j = 0
        for (i in 1 until N) {
            var bit = N shr 1
            while (j and bit != 0) {
                j = j xor bit
                bit = bit shr 1
            }
            j = j xor bit
            if (i < j) {
                var t = re[i]; re[i] = re[j]; re[j] = t
                t = im[i]; im[i] = im[j]; im[j] = t
            }
        }
        var len = 2
        while (len <= N) {
            val ang = -2 * PI / len
            val wr = cos(ang).toFloat()
            val wi = sin(ang).toFloat()
            var i = 0
            while (i < N) {
                var cr = 1f
                var ci = 0f
                for (k in 0 until len / 2) {
                    val a = i + k
                    val c = a + len / 2
                    val xr = re[c] * cr - im[c] * ci
                    val xi = re[c] * ci + im[c] * cr
                    re[c] = re[a] - xr; im[c] = im[a] - xi
                    re[a] += xr; im[a] += xi
                    val ncr = cr * wr - ci * wi
                    ci = cr * wi + ci * wr
                    cr = ncr
                }
                i += len
            }
            len = len shl 1
        }
    }

    /** Для страницы: "12,40,…" — уровни, которые сейчас звучат; пустая строка — звука нет */
    fun snapshot(): String {
        val want = System.currentTimeMillis() - DELAY_MS
        var best: Frame? = null
        synchronized(history) {
            for (f in history) if (f.time <= want) best = f
        }
        val f = best ?: return ""
        if (want - f.time > 400) return ""
        return f.levels.joinToString(",")
    }
}
